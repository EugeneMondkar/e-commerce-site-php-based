


<div class="btn-group-vertical" role="group" aria-label="Button Group">

	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'admin-page.php'" >Home</button>
  	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'admin-payroll.php'" >Payroll</button>
  	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'admin-employee-list.php'">Employee<br />List</button>
	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'forum.php'">Forum</button>
	

</div>
				

