<p class="text-warning h6 col-sm-6">Company Portal, Authorized Users Only</p>
<p class="text-warning h6 col-sm-6">For Assistance with Employment Questions <br />Contact Human Resources: 1-800-555-5555 <br />For Technical Assistance <br /> Contact Help Desk: 1-800-555-5556</p>
