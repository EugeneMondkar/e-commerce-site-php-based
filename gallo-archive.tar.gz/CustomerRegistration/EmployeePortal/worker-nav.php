


<div class="btn-group-vertical" role="group" aria-label="Button Group">
	
	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'worker-page.php'" >Home</button>
  	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'worker-timecard.php'" >Timecard</button>
	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'worker-workhistory.php'" >Work<br />History</button>
  	<button type="button" class="btn btn-warning" 
	onclick="location.href = 'forum.php'">Forum</button>
</div>
				

