<p class="text-warning h6 col-sm-6">Providing Gourmet Foods Since 1954</p>
<p class="text-warning h6 col-sm-6">Contact Us: 1-800-LUV-FOOD</p>
<p class="text-warning h6 col-sm-6"><a href="EmployeePortal/" class="text-warning">Employee Portal</a></p>
